import json

def lambda_handler(event, context):
    if 'body' in event:
        request_data = event['body']
    
        print("Dados recebidos:", request_data)
    
        response = {
            "statusCode": 200,
            "body": "Dados recebidos com sucesso: {}".format(request_data)
        }
    else:
        response = {
            "statusCode": 400,
            "body": "Nenhum dado encontrado na requisição"
        }
    
    return response

